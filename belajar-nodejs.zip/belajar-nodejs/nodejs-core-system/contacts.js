const {
    rejects
} = require('assert');
const fs = require('fs');
const readline = require('node:readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});

// Membuat folder, jika tidak ada

const makePath = './data';
if (!fs.existsSync(makePath)) {
    fs.mkdirSync(makePath);
}

// Mmebuat file, jika tidak ada

const makeFile = './data/contact.json';
if (!fs.existsSync(makeFile)) {
    fs.writeFileSync(makeFile, '[]', 'utf-8');
};

const makeQuestion = (question) => {
    return new Promise((resolve, reject) => {
        rl.question(question, (name) => {
            resolve(name);
        })
    })
}

const saveContact = (name, phone, email) => {
    const contact = {
        name,
        phone,
        email
    };
    const file = fs.readFileSync('data/contact.json', 'utf-8');
    const contacts = JSON.parse(file);

    contacts.push(contact);

    fs.writeFileSync('data/contact.json', JSON.stringify(contacts));

    console.log('Terimakasih sudah memasukan Data.');
    rl.close();
}

module.exports = {
    makeQuestion,
    saveContact
};