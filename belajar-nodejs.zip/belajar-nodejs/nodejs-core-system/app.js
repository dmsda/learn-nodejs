const {
    makeQuestion,
    saveContact
} = require('./contacts');

const main = async () => {
    const name = await makeQuestion('Please input your Name :');
    const email = await makeQuestion('Please input your Email :');
    const phone = await makeQuestion('Please input your Phone :');

    saveContact(name, phone, email);


}

main();