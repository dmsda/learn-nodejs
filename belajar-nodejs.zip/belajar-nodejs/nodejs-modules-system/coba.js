const sapaSalam = (nama) => `Halo ${nama}, apa kabar?`;

module.exports = sapaSalam;