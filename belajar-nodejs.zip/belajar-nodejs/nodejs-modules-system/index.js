// const fs = require('fs'); //core modules
const sapaSalam = require('./coba'); //local modules dengan relative URL
// const moment = require('moment'); //thirtparty modules atau NPM

console.log(sapaSalam('Dimas'));


// console.log("Selamat datang kembali di halaman utama!");