import chalk from 'chalk';

console.log(chalk.bgWhite.red("Hai, dimas"));